/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package tugas.data.ktp.tugas.java.data.ktp;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 *
 * @author user
 */
@Controller
public class TableController {
    
    @RequestMapping("/dataktp")
    //@ResponseBody
    public String getTable(Model tiki){
        String result = "=========Data KTP Penduduk Indonesia========="; 
        tiki.addAttribute("expedisi", result);
        
        //DataTable data = new DataTable();
        ArrayList<List<String>> data = new ArrayList<>();
        
        
        data.add(0,Arrays.asList("ID","Nomer KTP","Nama","Alamat"));
        data.add(1,Arrays.asList("1","6352749182736452","Jamaludin","Jakarta"));
        data.add(2,Arrays.asList("2","8935742975467843","Arif","Surabaya"));
        data.add(3,Arrays.asList("3","1524375893645386","Dinda sari","Sulawesi"));
        data.add(4,Arrays.asList("4","8375638567817583","Nurkolis","Bandunng"));
        data.add(5,Arrays.asList("5","7612739965837352","Firmansyah","Garut"));
        data.add(6,Arrays.asList("6","9037496173846539","Laura","TanjungPinang"));
        data.add(7,Arrays.asList("7","8937650365836582","Fatih","Sulawesi"));
        data.add(8,Arrays.asList("8","7463558374538565","Riski Hidayat","Indramayu"));
        data.add(9,Arrays.asList("9","1264735348496509","Dimas Prasetya","Yogyakarta"));
        data.add(10,Arrays.asList("10","7006426386774826","Alif Rahman","Malang"));
        data.add(11,Arrays.asList("11","7982462675476463","Naufal","Yogyakarta"));
        data.add(12,Arrays.asList("12","4378297638475364","Wiratama","Sumbawa"));
        data.add(13,Arrays.asList("13","7836523865498457","Indah","Tegal"));
        data.add(14,Arrays.asList("14","5267452386596385","Tanti Hayati","Cirebon"));
        data.add(15,Arrays.asList("15","3248634936596346","Alfiansyah","Sumedang"));
        data.add(16,Arrays.asList("16","6385487562376435","Askar","Makassar"));
        data.add(17,Arrays.asList("17","3279594765468474","Dhiasti","Kebumen"));
        data.add(18,Arrays.asList("18","6823641734832583","Nourin Alam","Brebes"));
        data.add(19,Arrays.asList("19","5328746326473952","Danang","Yogyakarta"));
        data.add(20,Arrays.asList("20","1323773485738526","Ajis","yogya"));
        
        tiki.addAttribute("tabel", data);
        
        
        return "tableviewer";            
    }
}